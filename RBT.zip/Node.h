template<class T>
struct Node
{
	T data;
	char colour;
	Node* left;
	Node* right;
	int count;
};

